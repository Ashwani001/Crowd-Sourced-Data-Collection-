/** Automatically generated file. DO NOT MODIFY */
package sg.blogspot.ce9005project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}