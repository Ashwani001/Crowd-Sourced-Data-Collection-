package sg.blogspot.ce9005project;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.app.Dialog;
import android.content.Intent;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class MainActivity extends FragmentActivity implements LocationListener, OnMapClickListener{	
	public static int globalfruitchoice =0;
	boolean dataloaded=false;
	String userAddress;
	static String datamat[][]={null};
	static String[] rows={null};
	final String myTag="DocUpload";
	private GoogleMap googlemap;
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// url to make request//https://
	//private static String url="https://script.google.com/macros/s/AKfycbwVy9z4SkRD73qaSFvB3eXxfAFofdZk5dlxo3BTQMPuworJEIMH/exec";//?json=callback";
	private static String url="https://docs.google.com/spreadsheet/pub?key=0ApvqX5TtdVUIdGdDU3NWbms4Tm1PT3VVUk9Ya0hYUkE&single=true&gid=0&output=txt";
	



	// contacts JSONArray
	JSONArray fruitdata = null;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        //setupMap();
        
        Log.d("ash",url);
        	

        
        if(isGooglePlay()){
        	
        	Toast.makeText(this, "Check 0", Toast.LENGTH_SHORT).show();
        	setContentView(R.layout.activity_main);
        	setupMap(); 

	        Log.d("ash","SETUP FINISHED");
        	t1.start();
	        Log.d("ash","RUN LIAO");
	        do{
	        	markerloader();

	    		//Log.d("ash ","waiting for permission to load markers");
	        }while(dataloaded==false);
	        
        	
        }
       
   		if(savedInstanceState == null) {
   		Toast.makeText(this, "Check 1", Toast.LENGTH_SHORT).show();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.map, new PlaceholderFragment())
                .commit();       
        //just moved this chunk from below this if to inside it
   		}        
   	
   		googlemap.setOnMapClickListener(this);
   		Toast.makeText(this, "Check 2", Toast.LENGTH_SHORT).show();
    }
    
    
	 Thread t1 = new Thread(new Runnable(){
	 		

			@Override
			public void run() {
				
				// TODO Auto-generated method stub

		        Log.d("ash","Going to fetchdata");
				try {
					fetchdata();

			        Log.d("ash","fetched data");
				} catch (IOException e) {

			        Log.d("ash","Failed to fetchdata");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
    
    
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {   
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == R.id.action_changefruit) {
            startActivity(new Intent(this, ChangeFruit.class));
        }
        else if(id==R.id.action_legalnotices){
        	startActivity(new Intent(this, LegalNoticesActivity.class));
        }
      return super.onOptionsItemSelected(item);
    }
    
    //Checks if play services available or not
    private boolean isGooglePlay(){
    	int status=GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
    	if(status==ConnectionResult.SUCCESS){
    		return(true);
    	}
    	else{
    		((Dialog) GooglePlayServicesUtil.getErrorDialog(status, this, 10)).show();
    		//Toast.makeText(this, "Google Play is not available", Toast.LENGTH_SHORT).show();
    	}
    	return(false);
    }
    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        public PlaceholderFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }
    }
    private void setupMap() {
    	if(googlemap==null){
    		Toast.makeText(this, "Check 3", Toast.LENGTH_SHORT).show();
    		googlemap=((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
    		//onLocationChanged(Location location); which part to add at?????
    		if(googlemap!=null){
    			Toast.makeText(this, "Check 4", Toast.LENGTH_SHORT).show();
    			//add some code to initialize map
    			googlemap.setMyLocationEnabled(true);
    			LocationManager lm=(LocationManager) getSystemService(LOCATION_SERVICE);
    			String provider = lm.getBestProvider(new Criteria(), true);
    			if(provider==null){
    				onProviderDisabled(provider);//tell user to on gps or wifi to get location below in function
    			}
    			Location loc=lm.getLastKnownLocation(provider);
    			if(loc!=null){
    				Toast.makeText(this, "Check 5", Toast.LENGTH_SHORT).show();
    				onLocationChanged(loc);
    			}				
    		}
    	}
    }
    public void onLocationChanged(Location location){
    	Toast.makeText(this, "Check 6", Toast.LENGTH_SHORT).show();
    	LatLng latlng=new LatLng(location.getLatitude(),location.getLongitude());
    	googlemap.moveCamera(CameraUpdateFactory.newLatLng(latlng));
    	googlemap.animateCamera(CameraUpdateFactory.zoomTo(15));
    }
    public void onProviderDisabled(String provider){
    	Toast.makeText(this, "Please siwtch on your GPS", Toast.LENGTH_LONG).show();
    	System.out.println("Please siwtch on your GPS.");
    }
    public void onProviderEnabled(String provider){//problem: gps off then uses last known location but when on then does not
    }
    public void onStatusChanged(String provider, int status, Bundle extras){
    }
    
	public void onMapClick(LatLng arg0){
	
		if(globalfruitchoice==R.id.mango){
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.mango)));	
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	";"+UserEmailFetcher.getEmail(this));
    		uploader.addEntry("2083084886", (";"+(arg0.latitude)).toString());
    		uploader.addEntry("2017421656", (";"+(arg0.longitude)).toString());//changed from arg0
    		getMyLocationAddress(arg0);
    		uploader.addEntry("406596175", ";"+userAddress);
    		uploader.addEntry("1553244498", ";Mango");
    		uploader.addEntry("310355343", ";Image URL");
    		uploader.upload();
		}
    	else if(globalfruitchoice==R.id.durian){
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.durian)));
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	";"+UserEmailFetcher.getEmail(this));
    		uploader.addEntry("2083084886", (";"+(arg0.latitude)).toString());
    		uploader.addEntry("2017421656", (";"+(arg0.longitude)).toString());//changed from arg0
    		getMyLocationAddress(arg0);
    		uploader.addEntry("406596175", ";"+userAddress);
    		uploader.addEntry("1553244498", ";Durian");
    		uploader.addEntry("310355343", ";Image URL");
    		uploader.upload();
    	}
    	else if(globalfruitchoice==R.id.rambutan){  		
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.rambutan)));
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	";"+UserEmailFetcher.getEmail(this));
    		uploader.addEntry("2083084886", (";"+(arg0.latitude)).toString());
    		uploader.addEntry("2017421656", (";"+(""+arg0.longitude).toString()));
    		getMyLocationAddress(arg0);
    		uploader.addEntry("406596175", ";"+userAddress);
    		uploader.addEntry("1553244498", ";Rambutan");
    		uploader.addEntry("310355343", ";Image URL");
    		uploader.upload();
    	}
    }
    
	public void getMyLocationAddress(LatLng arg1) {

		Geocoder geocoder= new Geocoder(this, Locale.ENGLISH);

		try {
			  List<Address> addresses = geocoder.getFromLocation(arg1.latitude,arg1.longitude, 1);
        	  if(addresses != null) {
        		  Address fetchedAddress = addresses.get(0);
        		  StringBuilder strAddress = new StringBuilder();
        	   
        		  for(int i=0; i<1+fetchedAddress.getMaxAddressLineIndex(); i++) {//I added the +1, seems to work better
        			  	strAddress.append(fetchedAddress.getAddressLine(i)).append("\n");
        		  }
        		  userAddress=(strAddress.toString());
        	  }
        	  
        	  else
        		  userAddress=("No location found!");
         
        } 
		catch (IOException e) {
        		 // TODO Auto-generated catch block
        		 e.printStackTrace();
        		 Toast.makeText(getApplicationContext(),"Could not get address!", Toast.LENGTH_LONG).show();
        		 userAddress=("Could not get address!");
		}
	}
	
	
	
	
	
	void fetchdata() throws IOException{

		String data = JSONParser.readJsonFromUrl(url);

   //     Log.d("ash ",data);
   
	     rows = data.split("\n");
	
	    String[][] matrix = new String[rows.length][]; 
	    int r = 0;
	    for (String row : rows) {
	        matrix[r++] = row.split("\\;");
	    }
	   // Log.d("ash ",matrix[3][2]+".");
	    //Log.d("ash ",matrix[3][5]);

	    for(int j = 1; j < rows.length; j++)
	    {
	    	matrix[j][2]=matrix[j][2].trim();
	    	matrix[j][3]=matrix[j][3].trim();
	    	matrix[j][4]=matrix[j][4].trim();
	    }
	    Log.d("ash ",matrix[3][2]+".");
	    
	    datamat=matrix;

		Log.d("ash ","before boleen set");
	    dataloaded=true;
		Log.d("ash ","after boleen set to true");
	}
	
	void markerloader(){
		if(dataloaded==false)
			return;
		else{
			Log.d("ash ","right before loop");
		    for(int i = 1; i < rows.length; i++){
		    	 Log.d("ash ","inside loop");
		    	 Log.d("ash ","matrix[i][2] is:"+datamat[i][2]);
		    	 LatLng arg2=new LatLng((Double.parseDouble(datamat[i][3])) , (Double.parseDouble(datamat[i][4])));
		    	 if(datamat[i][2].equals("Mango"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.mango)));
		    	 else if(datamat[i][2].equals("Durian"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.durian)));
		    	 else if(datamat[i][2].equals("Rambutan"))
		    	 {
		    	   Log.d("ash ","adding marker");
		    	   googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.rambutan)));
		    	 }
		    }
        }
	}
}