package sg.blogspot.ce9005project;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ChangeFruit extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_change_fruit);
		//Toast.makeText(this, "Test test test", Toast.LENGTH_SHORT).show();
		configureImageButton();
		}

	public void configureImageButton(){
	
		ImageButton btn=(ImageButton) findViewById(R.id.mango);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				//Toast.makeText(ChangeFruit.this, "Mango Mango", Toast.LENGTH_SHORT).show();
				MainActivity.globalfruitchoice=R.id.mango;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.durian);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				//Toast.makeText(ChangeFruit.this, "Durian Durian", Toast.LENGTH_SHORT).show();
				MainActivity.globalfruitchoice=R.id.durian;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.rambutan);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				//Toast.makeText(ChangeFruit.this, "Rambutan Rambutan", Toast.LENGTH_SHORT).show();
				MainActivity.globalfruitchoice=R.id.rambutan;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.noactivity);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				//Toast.makeText(ChangeFruit.this, "Rambutan Rambutan", Toast.LENGTH_SHORT).show();
				MainActivity.globalfruitchoice=R.id.noactivity;
				finish();
			}
		});
			
	}
}
	/*
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    int id = item.getItemId();
	    Toast.makeText(this, "Mango", Toast.LENGTH_SHORT).show();
	    if (id == R.id.mango) {
	    	MainActivity.globalfruitchoice=id;
	    	return true;
	    }
	    if (id == R.id.durian) {
	    	Toast.makeText(this, "Durian", Toast.LENGTH_SHORT).show();
	    	MainActivity.globalfruitchoice=id;
	    	return true;
	    }
	    if(id==R.id.rambutan){
	    	MainActivity.globalfruitchoice=id;
	    	return true;
	    }
	    else if(id==R.id.noactivity){
	    	MainActivity.globalfruitchoice=id;
	    	return true;
	    }
	  return super.onOptionsItemSelected(item);
	  }
}*/


/*@Override
public boolean onOptionsItemSelected(MenuItem item) {
// Handle item selection
switch (item.getItemId()) {
    case R.id.new_game:
        newGame();
        return true;
    case R.id.help:
        showHelp();
        return true;
    default:
        return super.onOptionsItemSelected(item);
}
}*/

/* From layout file
 
 <RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:paddingBottom="@dimen/activity_vertical_margin"
    android:paddingLeft="@dimen/activity_horizontal_margin"
    android:paddingRight="@dimen/activity_horizontal_margin"
    android:paddingTop="@dimen/activity_vertical_margin"
    tools:context="sg.blogspot.ce9005project.ChangeFruit$PlaceholderFragment" >
    

    <ImageButton
        android:id="@+id/durian"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentLeft="true"
        android:layout_alignParentTop="true"
        android:layout_marginLeft="53dp"
        android:layout_marginTop="95dp"
        android:src="@drawable/durian" />

    <ImageButton
        android:id="@+id/mango"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentLeft="true"
        android:layout_below="@+id/durian"
        android:layout_marginLeft="53dp"
        android:src="@drawable/mango" />

    <ImageButton
        android:id="@+id/rambutan"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentLeft="true"
        android:layout_below="@+id/mango"
        android:layout_marginLeft="53dp"
        android:src="@drawable/rambutan" />

    <TextView
        android:id="@+id/textView1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignBottom="@+id/durian"
        android:layout_marginBottom="18dp"
        android:layout_marginLeft="22dp"
        android:layout_toRightOf="@+id/durian"
        android:text="Durian"
        android:textAppearance="?android:attr/textAppearanceLarge" />

    <TextView
        android:id="@+id/textView2"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignBottom="@+id/mango"
        android:layout_alignLeft="@+id/textView1"
        android:layout_marginBottom="16dp"
        android:text="Mango"
        android:textAppearance="?android:attr/textAppearanceLarge" />

    <TextView
        android:id="@+id/textView3"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignBottom="@+id/rambutan"
        android:layout_alignLeft="@+id/textView2"
        android:layout_marginBottom="17dp"
        android:text="Rambutan"
        android:textAppearance="?android:attr/textAppearanceLarge" />

    <ImageButton
        android:id="@+id/noactivity"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignLeft="@+id/rambutan"
        android:layout_below="@+id/rambutan"
        android:src="@drawable/none" />

    <TextView
        android:id="@+id/textView4"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignLeft="@+id/textView3"
        android:layout_alignParentRight="true"
        android:layout_alignTop="@+id/noactivity"
        android:text="Just Monkey Around              &lt;Viewing Mood>"
        android:textAppearance="?android:attr/textAppearanceMedium" />

</RelativeLayout>
 */
