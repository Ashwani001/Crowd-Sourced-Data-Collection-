package sg.blogspot.ce9005project;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;


public class MainActivity extends FragmentActivity implements LocationListener, OnMapClickListener{	
	public static int globalfruitchoice =R.id.viewingmood;//This ensures default mood is viewing mood (Check function OnMapClick)
	boolean dataloaded=false;
	String userAddress;
	static String datamat[][]={null};
	static String[] rows={null};
	final String myTag="DocUpload";
	private GoogleMap googlemap;
	
	//Url to make request to. 
	//Place your published text output link here
	private static String url="https://docs.google.com/spreadsheet/pub?key=0ApvqX5TtdVUIdGdDU3NWbms4Tm1PT3VVUk9Ya0hYUkE&single=true&gid=0&output=txt";

	JSONArray fruitdata = null;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
               
        if(isGooglePlay()){
        	setContentView(R.layout.activity_main);
            isLocation();
            setupMap(); 
        	t1.start();
        	Log.d("ash","Going to load");
	        do{
	        	markerloader();
	        }while(dataloaded==false);
        }Log.d("ash","LOADED!");
        if(dataloaded==false)
        	Log.d("ash","data didnt load");
        else
        	Log.d("ash","dataloaded");
       
   		if(savedInstanceState == null) {
        getSupportFragmentManager().beginTransaction()
                .add(R.id.map, new PlaceholderFragment())
                .commit();       
   		}        
   		googlemap.setOnMapClickListener(this);
    }
    
    
	 Thread t1 = new Thread(new Runnable(){//The new tread is so that the app fetches the data in the background.
			@Override
			public void run(){		
				// TODO Auto-generated method stub
				try {
					Log.d("ash","going to call fetch");
					fetchdata();
					Log.d("ash","caled fetch");
				} catch (IOException e) {
					Log.d("ash","failed to fetch");
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {   
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_about) {
            startActivity(new Intent(this, about.class));
        }
        if (id == R.id.action_changefruit) {
            startActivity(new Intent(this, ChangeFruit.class));
        }
        else if(id==R.id.action_legalnotices){
        	startActivity(new Intent(this, LegalNoticesActivity.class));
        }
      return super.onOptionsItemSelected(item);
    }
    
    //Checks if play services available or not
    private boolean isGooglePlay(){
    	int status=GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
    	if(status==ConnectionResult.SUCCESS){
    		return(true);
    	}
    	else{
    		((Dialog) GooglePlayServicesUtil.getErrorDialog(status, this, 10)).show();
    	}
    	return(false);
    }
    
private void isLocation(){
	LocationManager service = (LocationManager) getSystemService(LOCATION_SERVICE);
	boolean enabled = service
	  .isProviderEnabled(LocationManager.GPS_PROVIDER);
	
	if (!enabled) {
		new AlertDialog.Builder(this)
	    .setTitle("Error!")
	    .setMessage("\nLocation Services are off. \n Please switch on your location serivces from settings!")    
	    .setIcon(android.R.drawable.ic_dialog_alert)
	    .show();
	}
}

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        public PlaceholderFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }
    }
    private void setupMap() {
    	if(googlemap==null){
    		googlemap=((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
    		if(googlemap!=null){
    			googlemap.setMyLocationEnabled(true);
    			LocationManager lm=(LocationManager) getSystemService(LOCATION_SERVICE);
    			String provider = lm.getBestProvider(new Criteria(), true);
    			if(provider==null){
    				onProviderDisabled(provider);//tell user to on gps or wifi to get location below in function
    			}
    			Location loc=lm.getLastKnownLocation(provider);
    			if(loc!=null){
    				onLocationChanged(loc);
    			}
    		}
    	}
    }
    public void onLocationChanged(Location location){
    	LatLng latlng=new LatLng(location.getLatitude(),location.getLongitude());
    	googlemap.moveCamera(CameraUpdateFactory.newLatLng(latlng));
    	googlemap.animateCamera(CameraUpdateFactory.zoomTo(20));
    }
    public void onProviderDisabled(String provider){
    }
    public void onProviderEnabled(String provider){
    }
    public void onStatusChanged(String provider, int status, Bundle extras){
    }
    
	public void onMapClick(LatLng arg0){//This function is called when user places an icon on the map by clicking
	//You can change it to OnLongMapClick(LatLng arg0) if you want users to click n hol longer before marker is placed
		if((globalfruitchoice!=R.id.viewingmood)) //This means a fruit has been selected
			{
			//This indicates new a entry. Change the address inside the "" to the id of your google form.
			GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	";"+UserEmailFetcher.getEmail(this));//Gets user email Id. Remove if you do not need it
    		uploader.addEntry("2083084886", (";"+(arg0.latitude)).toString());//change from arg0 (without .latitude) if you wish to store lat and lng together
    		uploader.addEntry("2017421656", (";"+(arg0.longitude)).toString());//if you changed to arg0 then remove this line
    		uploader.addEntry("310355343", ";Image URL");//Is is meant to hold the location of the image of the tree. Function not built yet.
    		getMyLocationAddress(arg0);//This fetches the address based on the coordinates
    		uploader.addEntry("406596175", ";"+userAddress);//Uploades the address
			
    		//The following is written in if else as they are unique to each fruit.
			if(globalfruitchoice==R.id.mango){
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.mango_new)));	
	    		uploader.addEntry("1553244498", ";Mango");
			}
	    	else if(globalfruitchoice==R.id.durian){
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.durian)));
	    		uploader.addEntry("1553244498", ";Durian");
	    	}
	    	else if(globalfruitchoice==R.id.rambutan){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.rambutan_new)));
	    		uploader.addEntry("1553244498", ";Rambutan");	
	    	}
	    	else if(globalfruitchoice==R.id.guava){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.guava)));
	    		uploader.addEntry("1553244498", ";Guava");
	    	}
	    	else if(globalfruitchoice==R.id.pomegranate){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.pomegranate)));
	    		uploader.addEntry("1553244498", ";Pomegranate");
	    	}
	    	else if(globalfruitchoice==R.id.banana){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.banana)));
	    		uploader.addEntry("1553244498", ";Banana");
	    	}
	    	else if(globalfruitchoice==R.id.jackfruit){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.jackfruit)));
	    		uploader.addEntry("1553244498", ";Jackfruit");
	    	}
			/*Add this if you added more fruits
			 else if(globalfruitchoice==R.id.newfruit){  		
	    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.newfruit)));
	    		uploader.addEntry("1553244498", ";Newfruit");
	    	}
			 */
			uploader.upload();//This uploads the data for the placed marker
		}
    }
    
	public void getMyLocationAddress(LatLng arg1) {//This function generates a readable address based on latitude and longitude
		Geocoder geocoder= new Geocoder(this, Locale.ENGLISH);
		try {
			  List<Address> addresses = geocoder.getFromLocation(arg1.latitude,arg1.longitude, 1);
        	  if(addresses != null) {
        		  Address fetchedAddress = addresses.get(0);
        		  StringBuilder strAddress = new StringBuilder();
        	   
        		  for(int i=0; i<1+fetchedAddress.getMaxAddressLineIndex(); i++) {//I added the +1, seems to work better
        			  	strAddress.append(fetchedAddress.getAddressLine(i)).append("\n");
        		  }
        		  userAddress=(strAddress.toString());//passes the address to the public static called userAddress to be used in other functions
        	  }
        	  
        	  else//If it TRIES but FAILS to find an address based on the latitude and longitude values
        		  userAddress=("No location found!");
        } 
		catch (IOException e) {//This is when it is unable to TRY to find an address.
        		 // TODO Auto-generated catch block
        		 e.printStackTrace();
        		 userAddress=("Could not get address!");
		}
	}
	
	void fetchdata() throws IOException{//This function is responsible for fetching the data and placing it into a 2D matrix
		
		Log.d("ash","entered fetchdata");
		String data = JSONParser.readJsonFromUrl(url);//This is the line fetching the data
		Log.d("ash",data);
	     rows = data.split("\n");//This indicates every '\n' indicates a new row
	
	    String[][] matrix = new String[rows.length][]; 
	    int r = 0;
	    for (String row : rows) {
	        matrix[r++] = row.split("\\;");//This says that every ';' indicates a new data cell
	    }

	    for(int j = 1; j < rows.length; j++)
	    {
	    	matrix[j][2]=matrix[j][2].trim();//This removed the white space in the data. 
	    	matrix[j][3]=matrix[j][3].trim();//This is so that you can use statements such as if(matrix[j][2]=="Banana")
	    	matrix[j][4]=matrix[j][4].trim();
	    }
	    datamat=matrix;//The information is passed to the public static matrix called datamat so that it can be used in other functions
	    dataloaded=true;//This indicated that the data has finished downloading
	}
	
	void markerloader(){//This function displays the location of the trees already marked
		if(dataloaded==false)
			return;//If the data on current tree locations has not been fully retrieved yet, the function does not place any markers.
		else
		{
		    for(int i = 1; i < rows.length; i++){
		    	//datama[i][2] holds the fruit name
		    	//datamat[i][3] holds the latitude while datamat[i][4] holds the longitude
		    	 LatLng arg2=new LatLng((Double.parseDouble(datamat[i][3])) , (Double.parseDouble(datamat[i][4])));
		    	 if(datamat[i][2].equals("Mango"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.mango_new)));
		    	 else if(datamat[i][2].equals("Durian"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.durian)));
		    	 else if(datamat[i][2].equals("Rambutan"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.rambutan_new)));
		    	 else if(datamat[i][2].equals("Guava"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.guava)));
		    	 else if(datamat[i][2].equals("Pomegranate"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.pomegranate)));
		    	 else if(datamat[i][2].equals("Banana"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.banana)));
		    	 else if(datamat[i][2].equals("Jackfruit"))
		    		 googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.jackfruit)));
		    	 //Add new fruits like this:
		    	 //else if(datamat[i][2].equals("newfruit"))
	    		 //googlemap.addMarker(new MarkerOptions().position(arg2).icon(BitmapDescriptorFactory.fromResource(R.drawable.newfruit)));
		    }
		}
	}
}