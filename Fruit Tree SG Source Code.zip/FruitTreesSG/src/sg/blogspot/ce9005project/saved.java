package sg.blogspot.ce9005project;

public class saved {

}
/*
 *package sg.blogspot.ce9005project;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.os.AsyncTask;
import android.util.Log;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.app.Dialog;
import android.content.Intent;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


public class MainActivity extends FragmentActivity implements LocationListener, OnMapClickListener{	
	public static int globalfruitchoice =0;
	String userAddress;
	final String myTag="DocUpload";
	private GoogleMap googlemap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        //setupMap();
        
      
        if(isGooglePlay()){
        	Toast.makeText(this, "Check 0", Toast.LENGTH_SHORT).show();
        	setContentView(R.layout.activity_main);
        	setupMap();     
        	
        }
       
   		if(savedInstanceState == null) {
   		Toast.makeText(this, "Check 1", Toast.LENGTH_SHORT).show();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.map, new PlaceholderFragment())
                .commit();       
        //just moved this chunk from below this if to inside it
   		}        
   	
   		googlemap.setOnMapClickListener(this);
   		Toast.makeText(this, "Check 2", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {   
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        if (id == R.id.action_changefruit) {
            startActivity(new Intent(this, ChangeFruit.class));
        }
        else if(id==R.id.action_legalnotices){
        	startActivity(new Intent(this, LegalNoticesActivity.class));
        }
      return super.onOptionsItemSelected(item);
    }
    
    //Checks if play services available or not
    private boolean isGooglePlay(){
    	int status=GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
    	if(status==ConnectionResult.SUCCESS){
    		return(true);
    	}
    	else{
    		((Dialog) GooglePlayServicesUtil.getErrorDialog(status, this, 10)).show();
    		//Toast.makeText(this, "Google Play is not available", Toast.LENGTH_SHORT).show();
    	}
    	return(false);
    }
    
    public static class PlaceholderFragment extends Fragment {
        public PlaceholderFragment() {
        }
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_main, container, false);
            return rootView;
        }
    }
    private void setupMap() {
    	if(googlemap==null){
    		Toast.makeText(this, "Check 3", Toast.LENGTH_SHORT).show();
    		googlemap=((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
    		//onLocationChanged(Location location); which part to add at?????
    		if(googlemap!=null){
    			Toast.makeText(this, "Check 4", Toast.LENGTH_SHORT).show();
    			//add some code to initialize map
    			googlemap.setMyLocationEnabled(true);
    			LocationManager lm=(LocationManager) getSystemService(LOCATION_SERVICE);
    			String provider = lm.getBestProvider(new Criteria(), true);
    			if(provider==null){
    				onProviderDisabled(provider);//tell user to on gps or wifi to get location below in function
    			}
    			Location loc=lm.getLastKnownLocation(provider);
    			if(loc!=null){
    				Toast.makeText(this, "Check 5", Toast.LENGTH_SHORT).show();
    				onLocationChanged(loc);
    			}				
    		}
    	}
    }
    public void onLocationChanged(Location location){
    	Toast.makeText(this, "Check 6", Toast.LENGTH_SHORT).show();
    	LatLng latlng=new LatLng(location.getLatitude(),location.getLongitude());
    	googlemap.moveCamera(CameraUpdateFactory.newLatLng(latlng));
    	googlemap.animateCamera(CameraUpdateFactory.zoomTo(15));
    }
    public void onProviderDisabled(String provider){
    	Toast.makeText(this, "Please siwtch on your GPS", Toast.LENGTH_SHORT).show();
    	System.out.println("Please siwtch on your GPS.");
    }
    public void onProviderEnabled(String provider){//problem: gps off then uses last known location but when on then does not
    }
    public void onStatusChanged(String provider, int status, Bundle extras){
    }
    
	@SuppressWarnings("null")
	public void onMapClick(LatLng arg0){
		//googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_launcher)));
    	if(globalfruitchoice==R.id.mango){
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.mango)));
    		
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	UserEmailFetcher.getEmail(this));
    		uploader.addEntry("1553244498", "Mango");
    		uploader.addEntry("2083084886", arg0.toString());
    		Log.i("Hello","0.0");
    		
    		
    		
    		Geocoder gc = new Geocoder(this);

    		//This chunk of code works but a lot of NULL
			/*List<Address> lister = null;
    		if(gc.isPresent()){
			try {
				lister = gc.getFromLocation(arg0.latitude,arg0.longitude,10);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Address address = lister.get(0);

    		  StringBuffer str = new StringBuffer();
    		  str.append("Name: " + address.getLocality() + "\n");
    		  str.append("Sub-Admin Ares: " + address.getSubAdminArea() + "\n");
    		  str.append("Admin Area: " + address.getAdminArea() + "\n");
    		  str.append("Country: " + address.getCountryName() + "\n");
    		  str.append("Country Code: " + address.getCountryCode() + "\n");

    		  //String strAddress = str.toString();
    		  userAddress= str.toString();;
    		}
    		
    		
    		
    		
    		uploader.addEntry("2017421656", "userAddress");
    		uploader.upload();
    	}
    	else if(globalfruitchoice==R.id.durian){
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.durian)));
    		
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	UserEmailFetcher.getEmail(this));
    		uploader.addEntry("1553244498", "Durian");
    		uploader.addEntry("2083084886", arg0.toString());
    		uploader.addEntry("2017421656", "Photo URL");
    		uploader.upload();
    	}
    	else if(globalfruitchoice==R.id.rambutan){  		
    		googlemap.addMarker(new MarkerOptions().position(arg0).icon(BitmapDescriptorFactory.fromResource(R.drawable.rambutan)));
    		  
    		
    		GoogleFormUploader uploader = new GoogleFormUploader("1SwM9M847FKqtCN-9Wi3LfIXZaOEYxyOQafbNT7x5BYM");
    		uploader.addEntry("455075755", 	UserEmailFetcher.getEmail(this));
    		uploader.addEntry("1553244498", "Rambutan");
    		uploader.addEntry("2083084886", arg0.toString());
    		uploader.addEntry("2017421656", "Photo URL");
    		uploader.upload();
    	}
    }
    
   

}
 */
