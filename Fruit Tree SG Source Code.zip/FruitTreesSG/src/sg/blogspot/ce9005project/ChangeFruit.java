package sg.blogspot.ce9005project;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class ChangeFruit extends Activity {

 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_change_fruit);
		configureImageButton();
		}

	public void configureImageButton(){
	
		ImageButton btn=(ImageButton) findViewById(R.id.mango);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.mango;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.durian);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.durian;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.rambutan);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.rambutan;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.banana);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.banana;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.jackfruit);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.jackfruit;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.guava);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.guava;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.pomegranate);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.pomegranate;
				finish();
			}
		});
		
		btn=(ImageButton) findViewById(R.id.viewingmood);
		btn.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				MainActivity.globalfruitchoice=R.id.viewingmood;
				finish();
			}
		});
	}	

}