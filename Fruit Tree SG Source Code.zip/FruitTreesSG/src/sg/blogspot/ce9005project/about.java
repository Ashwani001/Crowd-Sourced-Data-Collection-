package sg.blogspot.ce9005project;

import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;


public class about extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		
		TextView textView = (TextView) findViewById(R.id.textId);
		textView.setMovementMethod(new ScrollingMovementMethod());
		textView.setText("\n\n\n\t\t\t"
				+ "This app is intented to be an example for Crowd "
				+ "\tSourced Data Collection."
				+ "\n\n\n\t\t\t"
				+ "Please visit "
				+ "https://github.com/Ashwani001/Crowd-Sourced-Data-Collection- "
				+ "for the source code, user manual and if you would like to "
				+ "help build this app further."
				+ "\n\n\n\t\t\t"
				+ "Documentation on the formation of this app can be "
				+ "found over at"
				+ "http://screwthatnut.blogspot.sg/.");
	}
}

